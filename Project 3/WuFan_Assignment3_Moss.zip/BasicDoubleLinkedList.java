import java.util.ArrayList;	
import java.util.Comparator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

import org.junit.platform.engine.support.hierarchical.Node;

public class BasicDoubleLinkedList<T> implements Iterable {
	
	public class Node<T>{
		public T data;
		public Node<T> next;
		public Node<T> prev;
		public Node() {
			this.data = null;
			this.next = null;
			this.prev = null;
		}
		public Node(T data) {
			this.data = data;
		}
		public Node(T data, Node<T> n) {
			this.data = data;
			this.next = n;
		}
		public Node(T data, Node<T> n, Node<T> p) {
			this.data = data;
			this.next = n;
			this.prev = p;
		}
		
	}
	public Node<T> head;
	public int count;
	public Node<T> tail;
	public BasicDoubleLinkedList() {
		this.head = null;
		this.tail = null;
		this.count = 0;
	}
	
	public void addToEnd(T data){
		Node <T> temp = new Node<T>(data);
		if (this.tail == null) {
			this.head = temp;
			this.tail = temp;
		}else {
			this.tail.next = temp;
			temp.prev = tail;
			this.tail = temp;
		}
		this.count++;
	}

	public void addToFront(T data) {
		Node <T> temp = new Node<T>(data);
		if (this.head==null) {
			this.head = temp;
			this.tail = temp;
		}else {
			this.head.prev = temp;
			temp.next = this.head;
			this.head = temp;
			
		}
	}
	public int getSize() {
		return this.count;
	}
	
	public T getFirst() {
		return this.head.data;
	}
	
	public T getLast() {
		return this.tail.data;
	}
	
	public ListIterator<T> iterator(){
		return new InnerIter<>(this);
	}
	public class InnerIter<T> implements ListIterator<T>{
		ArrayList<T> arr;
		int i;
		public InnerIter(BasicDoubleLinkedList<T> b) {
			this.arr = b.toArrayList();
			i = 0;
		}
		public T next() {
			try {
				return arr.get(i++);
			} catch (IndexOutOfBoundsException e) {
				throw new NoSuchElementException();
			}
		}
		public boolean hasNext() {
			return i < arr.size();
		}
		@Override
		public boolean hasPrevious() {
			return i > 0;
		}
		@Override
		public T previous() {
			try {
				return arr.get(--i);
			} catch (IndexOutOfBoundsException e) {
				throw new NoSuchElementException();
			}
		}
		@Override
		public int nextIndex() {
			throw new UnsupportedOperationException();
		}
		@Override
		public int previousIndex() {
			throw new UnsupportedOperationException();
		}
		@Override
		public void remove() {
			throw new UnsupportedOperationException();
		}
		@Override
		public void set(T e) {
			throw new UnsupportedOperationException();
		}
		@Override
		public void add(T e) {
			throw new UnsupportedOperationException();
		}
		
	}
	
	public BasicDoubleLinkedList<T> remove(T targetData, Comparator<T> comparator){
		if (this.head == null || this.tail== null) {
			return this;
		}
		Node<T> temp = this.head;
		do {
			if (comparator.compare(temp.data, targetData) == 0) {
				if (temp == this.head) {
					this.head = temp.next;
					temp.next = null;
					this.head.prev= null;
				}else if (temp == this.tail) {
					this.tail = temp.prev;
					this.tail.next = null;
				}else {
					temp.prev.next = temp.next;
					temp.next.prev = temp.prev;
				}
				count--;
				return this;
			}
			temp = temp.next;
		} while (temp != null);
		return this;
	}
	
	public T retrieveFirstElement() {
		Node<T> temp = this.head;
		this.head = this.head.next;
		this.head.prev = null;
		return temp.data;
	}
	
	public T retrieveLastElement() {
		Node<T> temp = this.tail;
		this.tail = this.tail.prev;
		this.tail.next = null;
		return temp.data;
	}
	
	public ArrayList<T> toArrayList(){
		if (this.head == null || this.tail == null) return new ArrayList<T>();
		Node<T> temp = this.head;
		ArrayList<T> arr = new ArrayList<>();
		while (temp != null) {
			arr.add(temp.data);
			temp = temp.next;
		}
		return arr;
	}


}
