import java.util.ArrayList;
import java.util.Comparator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

public class SortedDoubleLinkedList<T> extends BasicDoubleLinkedList<T>{

	public Comparator<T> c;
	public SortedDoubleLinkedList(Comparator<T> abs) {
		super();
		this.c = abs;
	}
	public SortedDoubleLinkedList<T> add(T data1){
		if (head == null || tail == null) {
			head = new Node<T>(data1);
			tail= head;
		}else if (c.compare(this.head.data, data1)>= 0) {
			Node<T> temp = new Node<T>(data1);
			temp.next = head;
			head.prev = temp;
			head = temp;
		}else {
			Node<T> curr = this.head;
			while (curr.next != null && c.compare(curr.next.data, data1)<= 0) {
				curr = curr.next;
			}
			Node<T> temp = new Node<T>(data1);
			temp.next = curr.next;
			if (curr.next != null) {
				temp.next.prev = temp;
				
			}else {
				tail = temp;
			}
			curr.next = temp;
			temp.prev = curr;
		}
		super.count++;
		return this;
	}
	@Override
	public void addToEnd(T data){
		throw new java.lang.UnsupportedOperationException("Invalid operation for sorted list");
	}
	@Override
	public void addToFront(T data){
		throw new java.lang.UnsupportedOperationException("Invalid operation for sorted list");
	
	}
	
	public ListIterator<T> iterator(){
		return super.iterator();
	}
	
	public BasicDoubleLinkedList<T> remove(T targetData,Comparator<T> comparator){
		return super.remove(targetData, comparator);
	}
	public void print(){
		for (T a : toArrayList()) {
			System.out.println(a);
		}
		System.out.println("");
	}

}
